#pragma once

void DFS_for_maze();
void BFS_for_maze();
