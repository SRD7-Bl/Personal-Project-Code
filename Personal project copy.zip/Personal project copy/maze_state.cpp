#include "maze_state.hpp"

int n, m;
int Map[MAXN][MAXN];
int sx, sy, ex, ey;

int dx4[4] = {1, 0, -1, 0};
int dy4[4] = {0, 1, 0, -1};

bool vis[MAXN][MAXN];
int bestLen = INF;

std::vector<std::pair<int,int>> curPath, bestPath;
std::queue<point> q;

void init(){
    memset(vis,0,sizeof(vis));
    bestLen = INF;
    curPath.clear();
    bestPath.clear();
    while(!q.empty())q.pop();
}
